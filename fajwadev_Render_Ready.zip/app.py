import os, sqlite3, secrets, smtplib, hashlib, hmac, logging
import requests
from dotenv import load_dotenv
from datetime import datetime, date
from email.message import EmailMessage
from functools import wraps
from contextlib import closing
from xml.sax.saxutils import escape
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort, Response

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))
DB_PATH = os.path.abspath(os.environ.get("FAJWA_DB_PATH") or os.path.join(BASE_DIR, "instance", "fajwa.db"))
PUBLIC_SITE_URL = (os.environ.get("PUBLIC_SITE_URL") or os.environ.get("RENDER_EXTERNAL_URL") or "").rstrip("/")
app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", secrets.token_hex(32))
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"

SERVICES=[
("01","البحوث والدراسات","إعداد وتنظيم البحوث والدراسات العلمية بأسلوب منهجي واضح."),
("02","الإحصاء وتحليل البيانات","تحليل البيانات واستخراج المؤشرات والنتائج بصورة دقيقة ومنظمة."),
("03","التقارير","إعداد التقارير المهنية والعلمية وعرض النتائج بطريقة احترافية."),
("04","البرمجيات","تصميم وتطوير المواقع والأنظمة والحلول البرمجية حسب الحاجة."),
("05","إدارة المشاريع","تنظيم ومتابعة المشاريع ووضع الخطط ومؤشرات الأداء."),
("06","دراسات الجدوى","دراسات جدوى تساعد على فهم السوق والتكاليف والفرص والمخاطر."),
("07","الورش العلمية","ورش تدريبية وعلمية في مجالات البحث والتقنية وتحليل البيانات."),
("08","إدارة السوشال ميديا","إدارة المحتوى والحضور الرقمي وبناء هوية احترافية للعلامة التجارية.")]

# =========================
# إعداد الورشة الحالية
# ضع رابط Google Form هنا لعرض ورشة للزوار.
# إذا حذفت الرابط وجعلته "" ستظهر للزائر: لا توجد ورش حالياً.
# =========================
WORKSHOP_TITLE="ورشة العمل التنظيمية لإدارة وتطوير العمل المكتبي"
WORKSHOP_DESCRIPTION="ورشة علمية وتدريبية لتطوير وتنظيم العمل المكتبي ورفع كفاءة الأداء."
WORKSHOP_FORM_URL="https://docs.google.com/forms/d/e/1FAIpQLSe9livoBq8Ok0MenIPz1QCeo_QLZ-afjP9-p8SfNPGMzzGYpw/viewform?usp=publish-editor"
# تاريخ بداية الورشة بصيغة YYYY-MM-DD
WORKSHOP_START_DATE="2026-09-09"
# عدد أيام التقديم — غيّر هذا الرقم فقط عند الحاجة
WORKSHOP_DAYS=3
# أقل نسبة يظهر إليها الشريط في آخر يوم (مثلاً 10 = يبقى جزء صغير قبل النهاية)
WORKSHOP_PROGRESS_MIN=10

CONTACT_EMAIL="Fajwa.rd1@gmail.com"
ADMIN_USER=os.environ.get("FAJWA_ADMIN_USER","fajwa_admin")
ADMIN_HASH=os.environ.get("FAJWA_ADMIN_PASSWORD_HASH","")
EMAIL_PASSWORD=os.environ.get("FAJWA_EMAIL_PASSWORD","")

# =========================
# إعداد واتساب Business Cloud API
# =========================
# ضع رقم الاستقبال بصيغة دولية بدون + أو مسافات، مثال العراق: 9647xxxxxxxxx
WHATSAPP_TO=os.environ.get("WHATSAPP_TO","9647747755799")
WHATSAPP_PHONE_NUMBER_ID=os.environ.get("WHATSAPP_PHONE_NUMBER_ID","")
WHATSAPP_ACCESS_TOKEN=os.environ.get("WHATSAPP_ACCESS_TOKEN","")
WHATSAPP_API_VERSION=os.environ.get("WHATSAPP_API_VERSION","")
WHATSAPP_TEMPLATE_NAME=os.environ.get("WHATSAPP_TEMPLATE_NAME","new_service_request")
WHATSAPP_TEMPLATE_LANGUAGE=os.environ.get("WHATSAPP_TEMPLATE_LANGUAGE","ar")

logging.basicConfig(level=logging.INFO)
logger=logging.getLogger("fajwa")

def verify_password(password, encoded):
    try:
        salt_hex, rounds_s, digest_hex = encoded.split("$", 2)
        salt=bytes.fromhex(salt_hex); rounds=int(rounds_s)
        derived=hashlib.pbkdf2_hmac("sha256",password.encode(),salt,rounds)
        return hmac.compare_digest(derived.hex(),digest_hex)
    except Exception:
        return False


def get_db():
    os.makedirs(os.path.dirname(DB_PATH),exist_ok=True)
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c

def init_db():
    c=get_db(); c.execute("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL,email TEXT,service TEXT,message TEXT NOT NULL,created_at TEXT NOT NULL)"); c.commit(); c.close()

def send_email(name,phone,email,service,message):
    if not EMAIL_PASSWORD: return False
    msg=EmailMessage(); msg["Subject"]=f"طلب خدمة جديد - {name}"; msg["From"]=CONTACT_EMAIL; msg["To"]=CONTACT_EMAIL
    msg.set_content(f"الاسم: {name}\nالهاتف: {phone}\nالبريد: {email}\nالخدمة: {service}\n\nالطلب:\n{message}")
    with smtplib.SMTP("smtp.gmail.com",587,timeout=20) as s:
        s.starttls(); s.login(CONTACT_EMAIL,EMAIL_PASSWORD); s.send_message(msg)
    return True

def send_whatsapp(name, phone, email, service, message):
    """إرسال إشعار طلب جديد إلى واتساب عبر WhatsApp Cloud API.

    يستخدم قالب WhatsApp مع متغير واحد {{1}} يحتوي تفاصيل الطلب كاملة.
    خارج نافذة المحادثة لا يمكن الاعتماد على رسالة نصية حرة، لذلك القالب هو المسار الافتراضي.
    """
    if not (WHATSAPP_PHONE_NUMBER_ID and WHATSAPP_ACCESS_TOKEN and WHATSAPP_TO):
        logger.warning("WhatsApp is not configured; skipping notification.")
        return False

    details = (
        f"طلب خدمة جديد من موقع فجوة\n\n"
        f"الاسم: {name}\n"
        f"الهاتف: {phone}\n"
        f"البريد: {email or '-'}\n"
        f"الخدمة: {service or '-'}\n\n"
        f"تفاصيل الطلب:\n{message}"
    )

    if WHATSAPP_API_VERSION.strip():
        url = f"https://graph.facebook.com/{WHATSAPP_API_VERSION.strip()}/{WHATSAPP_PHONE_NUMBER_ID}/messages"
    else:
        url = f"https://graph.facebook.com/{WHATSAPP_PHONE_NUMBER_ID}/messages"

    payload = {
        "messaging_product": "whatsapp",
        "to": WHATSAPP_TO,
        "type": "template",
        "template": {
            "name": WHATSAPP_TEMPLATE_NAME,
            "language": {"code": WHATSAPP_TEMPLATE_LANGUAGE},
            "components": [
                {
                    "type": "body",
                    "parameters": [
                        {"type": "text", "text": details}
                    ]
                }
            ]
        }
    }

    headers = {
        "Authorization": f"Bearer {WHATSAPP_ACCESS_TOKEN}",
        "Content-Type": "application/json",
    }

    response = requests.post(url, headers=headers, json=payload, timeout=20)
    if not response.ok:
        logger.error("WhatsApp API error %s: %s", response.status_code, response.text[:1000])
        return False
    return True

def admin_required(fn):
    @wraps(fn)
    def wrapper(*a,**kw):
        if not session.get("admin_authenticated"): return redirect(url_for("admin_login",next=request.path))
        return fn(*a,**kw)
    return wrapper

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"]="nosniff"; response.headers["X-Frame-Options"]="SAMEORIGIN"; response.headers["Referrer-Policy"]="strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"]="geolocation=(), microphone=(), camera=()"
    if request.path.startswith("/admin") or response.status_code >= 400:
        response.headers["X-Robots-Tag"] = "noindex, nofollow"
    return response

def public_url(path):
    return (PUBLIC_SITE_URL or request.url_root.rstrip("/")) + path

@app.context_processor
def inject_globals():
    return {"company_name":"فجوة للبحث والتطوير","instagram":"fajwa.rd","services":SERVICES,"contact_email":CONTACT_EMAIL,"canonical_url":public_url(request.path),"site_url":public_url("/"),"logo_url":public_url(url_for("static", filename="images/logo.png"))}

@app.get("/healthz")
def health():
    with closing(get_db()) as db:
        db.execute("SELECT 1 FROM messages LIMIT 1")
    return {"status": "ok"}

@app.get("/robots.txt")
def robots():
    return Response("User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /healthz\nSitemap: " + public_url("/sitemap.xml") + "\n", mimetype="text/plain")

@app.get("/sitemap.xml")
def sitemap():
    paths = ["/", "/about", "/services", "/projects", "/workshops", "/request", "/contact"]
    entries = "".join("<url><loc>" + escape(public_url(path)) + "</loc></url>" for path in paths)
    return Response('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + entries + "</urlset>", mimetype="application/xml")

@app.route("/")
def home(): return render_template("index.html")
@app.route("/about")
def about(): return render_template("about.html")
@app.route("/services")
def services(): return render_template("services.html")
@app.route("/projects")
def projects(): return render_template("projects.html")
@app.route("/workshops")
def workshops():
    workshop = None
    if WORKSHOP_FORM_URL.strip():
        try:
            start = datetime.strptime(WORKSHOP_START_DATE, "%Y-%m-%d").date()
            days = max(1, int(WORKSHOP_DAYS))
            today = date.today()
            elapsed_days = (today - start).days

            # قبل البداية: الشريط ممتلئ. بعد انتهاء المدة: لا توجد ورشة.
            if elapsed_days < days:
                day_number = max(1, elapsed_days + 1)
                if days == 1:
                    progress = 100
                else:
                    # اليوم الأول 100%، وفي الأيام التالية ينخفض تدريجياً
                    progress = round(100 - ((day_number - 1) / (days - 1)) * (100 - WORKSHOP_PROGRESS_MIN))
                    progress = max(WORKSHOP_PROGRESS_MIN, min(100, progress))

                workshop = {
                    "title": WORKSHOP_TITLE,
                    "description": WORKSHOP_DESCRIPTION,
                    "form_url": WORKSHOP_FORM_URL.strip(),
                    "day_number": day_number,
                    "days": days,
                    "progress": progress,
                }
        except (ValueError, TypeError):
            # في حال كان التاريخ غير صحيح، لا نعطل الموقع بالكامل.
            workshop = {
                "title": WORKSHOP_TITLE,
                "description": WORKSHOP_DESCRIPTION,
                "form_url": WORKSHOP_FORM_URL.strip(),
                "day_number": None,
                "days": WORKSHOP_DAYS,
                "progress": 100,
            }
    return render_template("workshops.html", workshop=workshop)

@app.route("/request",methods=["GET","POST"])
def request_service():
    if request.method=="POST":
        name=request.form.get("name","").strip(); phone=request.form.get("phone","").strip(); email=request.form.get("email","").strip(); service=request.form.get("service","").strip(); message=request.form.get("message","").strip()
        if not name or not phone or not message:
            flash("يرجى ملء الاسم ورقم الهاتف وتفاصيل الطلب.","error"); return render_template("request.html")
        c=get_db(); c.execute("INSERT INTO messages (name,phone,email,service,message,created_at) VALUES (?,?,?,?,?,?)",(name,phone,email,service,message,datetime.now().strftime("%Y-%m-%d %H:%M:%S"))); c.commit(); c.close()
        try:
            send_email(name,phone,email,service,message)
        except Exception as exc:
            logger.exception("Email notification failed: %s", exc)

        try:
            send_whatsapp(name,phone,email,service,message)
        except Exception as exc:
            logger.exception("WhatsApp notification failed: %s", exc)

        flash("تم إرسال طلبك بنجاح. ستتواصل معك فجوة في أقرب وقت.","success"); return redirect(url_for("request_service"))
    return render_template("request.html")

@app.route("/contact")
def contact(): return render_template("contact.html")

@app.route("/admin/login",methods=["GET","POST"])
def admin_login():
    if request.method=="POST":
        if not ADMIN_HASH: flash("لم يتم إعداد كلمة مرور الإدارة بعد.","error"); return render_template("admin_login.html")
        user=request.form.get("username","").strip(); pw=request.form.get("password","")
        if secrets.compare_digest(user,ADMIN_USER) and verify_password(pw,ADMIN_HASH):
            session.clear(); session["admin_authenticated"]=True
            return redirect(request.args.get("next") or url_for("admin_messages"))
        flash("بيانات الدخول غير صحيحة.","error")
    return render_template("admin_login.html")

@app.route("/admin/logout")
def admin_logout(): session.clear(); return redirect(url_for("admin_login"))

@app.route("/admin/messages")
@admin_required
def admin_messages():
    c=get_db(); messages=c.execute("SELECT * FROM messages ORDER BY id DESC").fetchall(); c.close(); return render_template("admin_messages.html",messages=messages)

@app.errorhandler(404)
def not_found(error): return render_template("404.html"),404

init_db()
if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","5000")),debug=False)
